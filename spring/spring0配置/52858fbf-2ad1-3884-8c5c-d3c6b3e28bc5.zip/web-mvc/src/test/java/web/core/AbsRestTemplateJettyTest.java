/*
 * COPYRIGHT Beijing NetQin-Tech Co.,Ltd.                                   *
 ****************************************************************************
 * 源文件名:  web.core.AbsRestTemplateJettyTest.java 													       
 * 功能: cpframework框架													   
 * 版本:	@version 1.0	                                                                   
 * 编制日期: 2014年9月2日 下午4:39:03 						    						                                        
 * 修改历史: (主要历史变动原因及说明)		
 * YYYY-MM-DD |    Author      |	 Change Description		      
 * 2014年9月2日    |    Administrator     |     Created 
 */
package web.core;


/**
 * Description: <类功能描述>. <br>
 * <p>
 * <使用说明>
 * </p>
 * Makedate:2014年9月2日 下午4:39:03
 * 
 * @author Administrator
 * @version V1.0
 */
public abstract class AbsRestTemplateJettyTest {
//	private static Server server;
//
//	@BeforeClass
//	public static void beforeClass() throws Exception {
//		// 创建一个server
//		server = new Server(8080);
//		WebAppContext context = new WebAppContext();
//		String webapp = "src/main/webapp";
//		context.setDescriptor(webapp + "/WEB-INF/web.xml"); // 指定web.xml配置文件
//		context.setResourceBase(webapp); // 指定webapp目录
//		context.setContextPath("/webmvc");
//		context.setParentLoaderPriority(true);
//		server.setHandler(context);
//		server.start();
//		System.out.println("server start");
//		
//	}
//
//	@AfterClass
//	public static void afterClass() throws Exception {
//		Thread.sleep(100000);
//		server.stop(); // 当测试结束时停止服务器
//		System.out.println("server stop");
//	}

}
